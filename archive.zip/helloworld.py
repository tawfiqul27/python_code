# firts python script
# 

2+2

def main():         # this will define main function and colon starts the scope block
    print ("hello world")

if __name__=="__main__":
    main()



